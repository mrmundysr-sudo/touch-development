# Touch Developer — Version 1 Handoff

This package contains the complete build instructions for the first usable version of Touch Developer.

## What to do

1. Create a new OpenHands repository for this project.
2. Upload this entire ZIP to that repository.
3. Tell Codex when the ZIP is visible there.
4. Codex will provide the exact OpenHands build/start instructions and manage the remaining setup.

## Goal

Touch Developer is a phone-first Android control center for managing GitHub repositories, AI source-code instructions, OpenHands builds, APKs, source ZIPs, and complete project handoffs.

The first version focuses on this working path:

`Select repository → paste source/instructions → build through OpenHands → download APK and complete handoff ZIP`

Read `TOUCH-DEVELOPER-V1-BUILD-PROMPT.md` completely before building.


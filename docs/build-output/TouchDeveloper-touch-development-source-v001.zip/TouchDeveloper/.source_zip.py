import os
import zipfile

root = os.getcwd()
out = os.path.join(root, 'docs', 'build-output',
                   'TouchDeveloper-touch-development-source-v001.zip')
if os.path.exists(out):
    os.remove(out)

skip_dirs = {'.git', '.gradle', 'build', '.idea', 'captures'}
skip_files = {'local.properties'}
count = 0
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]
        rel_dir = os.path.relpath(dirpath, root)
        for f in filenames:
            abs_path = os.path.join(dirpath, f)
            if os.path.abspath(abs_path) == os.path.abspath(out):
                continue
            if f in skip_files or f.endswith('.apk'):
                continue
            arc = os.path.join('TouchDeveloper', f) if rel_dir == '.' \
                else os.path.join('TouchDeveloper', rel_dir, f)
            z.write(abs_path, arc)
            count += 1

print('entries:', count, 'size:', os.path.getsize(out))

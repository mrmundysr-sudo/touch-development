# Initial Project Structure

Recommended Android project structure:

```text
TouchDeveloper/
├── app/
│   └── src/main/java/com/touchdeveloper/app/
│       ├── MainActivity.java
│       ├── model/
│       ├── github/
│       ├── openhands/
│       ├── build/
│       ├── files/
│       └── safety/
├── README.md
└── TOUCH-DEVELOPER-V1-BUILD-PROMPT.md
```

The project must remain easy to package as a complete source ZIP and build through OpenHands.


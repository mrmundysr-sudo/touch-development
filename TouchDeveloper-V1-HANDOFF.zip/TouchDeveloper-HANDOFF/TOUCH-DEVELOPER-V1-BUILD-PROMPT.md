# Touch Developer — Version 1 Build Prompt

Build an Android app called **Touch Developer**.

The app is a phone-first control center for managing small Android projects through GitHub, AI instructions, and OpenHands.

## Project requirements

- Java
- Single Activity
- Package: `com.touchdeveloper.app`
- minSdk 26
- Portrait layout
- Simple functional placeholder visuals
- Do not create elaborate artwork or visual polish
- Use clear clickable buttons, menus, lists, dialogs, and status labels
- Keep the source organized so future features can be added easily

## Version 1 goal

The first version must allow the user to:

1. Connect one GitHub account or repository.
2. Display repositories.
3. Tap a repository to view its files.
4. Upload files and ZIP files.
5. Download files and ZIP files.
6. Open a file or ZIP when possible.
7. Paste source code and AI instructions.
8. Open the selected repository in OpenHands.
9. Start an Android build through the configured OpenHands/build workspace.
10. Display build progress.
11. Display successful or failed build status.
12. Display Gradle errors.
13. Copy build errors for AI assistance.
14. Download the successful APK.
15. Create and download a complete source handoff ZIP.

## Main screens

### Repository Dashboard

Show connected repositories with:

- Repository name
- Current branch
- Latest commit
- Build status
- Latest APK
- Latest source ZIP
- Status labels: Local, Committed, Pushed, Building, Successful, Failed
- Refresh button

Each repository must be clickable.

### Repository File Screen

Show the selected repository's files and folders in a simple list.

Tapping any file opens a popup menu with:

- Download
- Open or preview
- Copy
- Paste or replace
- Rename
- Delete
- Upload replacement
- Compare versions
- Restore previous version
- Add to build
- Exclude from build

Implement safe actions through the GitHub API. If an action is not implemented yet, show a clear “Coming in next version” message instead of pretending it worked.

### Repository Action Menu

Include:

- Pull latest changes
- Upload files
- Create branch
- Commit changes
- Push to GitHub
- Create source ZIP
- Build APK
- Download latest APK
- Download complete project
- Open in OpenHands
- Delete repository

Destructive actions require confirmation.

### AI Build Prompt Screen

Include:

- Large multiline field for source code
- Large multiline field for AI instructions
- Optional project ZIP upload
- Optional asset upload
- Selected repository display
- Selected branch display
- Build APK button
- Send to OpenHands button
- Create Handoff ZIP button

Example prompts:

- “Build the latest version.”
- “Fix the Gradle errors.”
- “Replace this image with the new one.”
- “Show me what changed.”
- “Create a complete source handoff.”

### Build Status Screen

Show:

- Project name
- Build status
- Live progress messages
- Build start time
- Build completion time
- Gradle output
- Error output
- Copy Errors button
- Send Errors to OpenHands button
- Rebuild button
- Download APK button
- Download Source ZIP button
- Download Complete Handoff button

### Handoff Package Screen

The complete handoff ZIP must contain:

- Full Android source project
- APK
- README.md
- AI instructions
- Source code
- Assets
- Build log
- Error log, if applicable
- Test results
- Version information
- Commit information
- SHA-256 checksums when available

Use a filename such as:

`TouchDeveloper-[project]-handoff-v001.zip`

## Safety requirements

- Confirm before deleting files.
- Require separate confirmation before deleting a repository.
- Protect current source, latest APK, handoff ZIP, and handoff instructions by default.
- Show exactly what will change before committing.
- Confirm before pushing publicly to GitHub.
- Keep an activity history of actions.
- Never claim an action succeeded unless the API or build result confirms it.
- Show clear errors when GitHub, OpenHands, or the build service is unavailable.
- Never store GitHub tokens in plain text.
- Use secure Android storage for credentials.
- Do not include credentials in source ZIPs or logs.

## Integration structure

Create clean service interfaces:

- `GitHubService`
- `OpenHandsService`
- `BuildService`
- `ZipService`
- `CredentialService`
- `ActivityLogService`

Use mock/demo data only when an integration is not configured, and clearly label it as demo mode.

Do not hardcode private tokens, passwords, API keys, or private URLs.

## Version 1 limitations

Do not attempt to build every advanced feature yet. Prioritize this working path:

`Repository → Files → AI instructions/source → OpenHands/build → APK + complete handoff ZIP`

Use simple placeholder screens and functional controls. The goal is a usable first build that can be tested on an Android phone and improved through later versions.

## Deliverables

Return:

1. Compiling Android Studio project
2. Debug APK
3. Complete source ZIP
4. README with setup and run instructions
5. Implemented-feature list
6. Placeholder-feature list
7. Required GitHub/OpenHands credentials or URLs
8. Build log
9. Known limitations
10. Exact testing steps for the first workflow

Before coding, report the files in this handoff, confirm that this handoff is the only specification being used, and provide the implementation plan. Do not use older Touch projects, prior code, or unrelated instructions.

